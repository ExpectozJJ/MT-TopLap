import gudhi, re, os, sys
import numpy as np

FRIDefault = [['Lorentz', 0.5,  5],
              ['Lorentz', 1.0,  5],
              ['Lorentz', 2.0,  5],
              ['Exp',     1.0, 15],
              ['Exp',     2.0, 15]]
ElementList = ['C', 'N', 'O']
ElementTau = np.array([6., 1.12, 1.1])
EleLength = len(ElementList)
dt = np.dtype([('dim', int), ('birth', float), ('death', float)])

class atom:
    def __init__(self, position, chain, resID, atype):
        self.pos   = np.array(position)
        self.chain = chain
        self.resID = resID
        self.atype = atype

class pro_complex:
    def __init__(self, structure, typeFlag):
        self.PDBid = structure.PDBid
        self.resID = structure.resID_Complex

        self.muteChain    = structure.muteChain
        self.OtherChains  = structure.OtherChains
        self.MutedPartner = structure.MutedPartner
        self.OtherPartner = structure.OtherPartner

        if typeFlag == 'WT':
            self.resName = structure.resWT
        elif typeFlag == 'MT':
            self.resName = structure.resMT
        else:
            sys.exit('wrong typeFlag for PPIcomplex.py')

        # point cloud of atoms 
        # '_b': binding;                 '_m': mutant
        # '_m': includes mutant residue; '_o': includes other part
        #                                '_s': includes other side
        self.atoms_b_m = [[] for _ in range(EleLength)]
        self.atoms_b_o = [[] for _ in range(EleLength)]
        self.atoms_m_m = [[] for _ in range(EleLength)]
        self.atoms_m_o = [[] for _ in range(EleLength)]
        self.atoms_m_s = [[] for _ in range(EleLength)]
        self.loadBindingPDB(structure.fileComplex+'_'+typeFlag+'_b.pdb')
        self.loadMutantPDB(structure.fileComplex+'_'+typeFlag+'_m.pdb')

    def loadBindingPDB(self, PDBfile):
        fp = open(PDBfile)
        for line in fp:
            if line[:4]=='ATOM':
                resID = int(line[23:26])
                if line[21] in self.MutedPartner and line[13] in ElementList:
                    Atom = atom([float(line[30:38]), float(line[38:46]), float(line[46:54])],
                                line[21], resID, line[13])
                    self.atoms_b_m[ElementList.index(Atom.atype)].append(Atom)
                elif line[21] in self.OtherPartner and line[13] in ElementList:
                    Atom = atom([float(line[30:38]), float(line[38:46]), float(line[46:54])],
                                line[21], resID, line[13])
                    self.atoms_b_o[ElementList.index(Atom.atype)].append(Atom)
        fp.close()
        return

    def loadMutantPDB(self, PDBfile):
        fp = open(PDBfile)
        for line in fp:
            if line[:4]=='ATOM':
                resID = int(line[23:26])
                if line[21]==self.muteChain and line[13] in ElementList and resID==self.resID:
                    Atom = atom([float(line[30:38]), float(line[38:46]), float(line[46:54])],
                                line[21], resID, line[13])
                    self.atoms_m_m[ElementList.index(Atom.atype)].append(Atom)
                elif line[13] in ElementList:
                    Atom = atom([float(line[30:38]), float(line[38:46]), float(line[46:54])],
                                line[21], resID, line[13])
                    self.atoms_m_o[ElementList.index(Atom.atype)].append(Atom)
                    if line[21] in self.OtherPartner:
                        self.atoms_m_s[ElementList.index(Atom.atype)].append(Atom)
        fp.close()
        return

    def rips_complex(self, atoms_m, atoms_o, interval=1., birth_cut=2., death_cut=11.):
        PHcut = death_cut+1.
        BinIdx = int((death_cut-birth_cut)/interval)
        Bins = np.linspace(birth_cut, death_cut, BinIdx+1)
        def BinID(x):
            for i in range(BinIdx):
                if Bins[i] <= x < Bins[i+1]:
                    return i
            return BinIdx # needs update here

        rips_dth = np.zeros([BinIdx, EleLength*EleLength])
        rips_bar = np.zeros([BinIdx, EleLength*EleLength])

        for idx_m, e_m in enumerate(ElementList):
            for idx_o, e_o in enumerate(ElementList):
                length_m = len(atoms_m[idx_m])
                length_o = len(atoms_o[idx_o])
                matrixA = np.ones((length_m+length_o, length_m+length_o))*100.
                for ii, iatom in enumerate(atoms_m[idx_m]):
                    for jj, jatom in enumerate(atoms_o[idx_o]):
                        dis = np.linalg.norm(iatom.pos-jatom.pos)
                        matrixA[ii, length_m+jj] = dis
                        matrixA[length_m+jj, ii] = dis
                rips_complex = gudhi.RipsComplex(distance_matrix=matrixA, max_edge_length=PHcut)
                PH = rips_complex.create_simplex_tree().persistence()

                tmpbars = np.zeros(length_m+length_o, dtype=dt)
                cnt = 0
                for simplex in PH:
                    dim, b, d = int(simplex[0]), float(simplex[1][0]), float(simplex[1][1])
                    if d-b < 0.1: continue
                    tmpbars[cnt]['dim']   = dim
                    tmpbars[cnt]['birth'] = b
                    tmpbars[cnt]['death'] = d
                    cnt += 1
                bars = tmpbars[0:cnt]
                for bar in bars:
                    death = bar['death']
                    if death>=death_cut or death<birth_cut: continue
                    Did = BinID(death)
                    rips_dth[ Did, idx_m*EleLength+idx_o] += 1
                    rips_bar[:Did, idx_m*EleLength+idx_o] += 1
        return np.array(rips_dth), np.array(rips_bar)

    #def rips_complex_spectra(self, atoms_m, atoms_o, interval=1., birth_cut=4., death_cut=11.):
        #BinIdx = int((death_cut-birth_cut)/interval)+1
        #Bins = np.linspace(birth_cut, death_cut, BinIdx)
    def rips_complex_spectra(self, atoms_m, atoms_o):
        Bins = [2, 3, 4, 5, 6, 7, 9, 11]
        BinIdx = len(Bins)
        features = np.zeros((BinIdx*EleLength*EleLength, 8), np.float)
        for idx_m, e_m in enumerate(ElementList):
            for idx_o, e_o in enumerate(ElementList):
                length_m = len(atoms_m[idx_m])
                length_o = len(atoms_o[idx_o])
                matrixA = np.ones((length_m+length_o, length_m+length_o))*100.
                for ii, iatom in enumerate(atoms_m[idx_m]):
                    for jj, jatom in enumerate(atoms_o[idx_o]):
                        dis = np.linalg.norm(iatom.pos-jatom.pos)
                        matrixA[ii, length_m+jj] = dis
                        matrixA[length_m+jj, ii] = dis

                for idx_cut, cut in enumerate(Bins):
                    Laplacian = np.zeros((length_m+length_o, length_m+length_o), np.int)
                    Laplacian[matrixA<cut] = -1
                    Laplacian += np.diagflat(-np.sum(Laplacian, axis=0))
                    eigens = np.sort(np.linalg.eigvalsh(Laplacian))

                    idx_feat = idx_cut*EleLength*EleLength+idx_m*EleLength+idx_o
                    eigens = eigens[eigens>10**-8]
                    if len(eigens) > 0:
                        #sum, min, max, mean, std, var,
                        features[idx_feat][0] = eigens.sum()
                        features[idx_feat][1] = eigens.min()
                        features[idx_feat][2] = eigens.max()
                        features[idx_feat][3] = eigens.mean()
                        features[idx_feat][4] = eigens.std()
                        features[idx_feat][5] = eigens.var()
                        features[idx_feat][6] = np.dot(eigens, eigens)
                        features[idx_feat][7] = len(eigens[eigens>10**-8])
                        #features[idx_feat][7]  = eigens[length_m-1]
                        #features[idx_feat][8]  = eigens[length_m]
                        #features[idx_feat][9]  = eigens[length_o-1]
                        #features[idx_feat][10] = eigens[length_o]
                        #check all the features' length == length_m+length_o CHECKED!
                    #print(features[idx_feat])
        return features.flatten() #rips_complex_spectra

    def alpha_shape(self, atoms_m, atoms_o):
        alpha_PH12 = np.zeros([EleLength, EleLength, 14])
        for idx_m, e_m in enumerate(ElementList):
            for idx_o, e_o in enumerate(ElementList):
                points  = [iatom.pos for iatom in atoms_m[idx_m]]
                points += [iatom.pos for iatom in atoms_o[idx_o]]
                alpha_complex = gudhi.AlphaComplex(points=points)
                PH = alpha_complex.create_simplex_tree().persistence()

                tmpbars = np.zeros(len(PH), dtype=dt)
                cnt = 0
                for simplex in PH:
                    dim, b, d = int(simplex[0]), float(simplex[1][0]), float(simplex[1][1])
                    if d-b < 0.1: continue
                    tmpbars[cnt]['dim']   = dim
                    tmpbars[cnt]['birth'] = b
                    tmpbars[cnt]['death'] = d
                    cnt += 1
                bars = tmpbars[0:cnt]
                if len(bars[bars['dim']==1]['death']) > 0:
                    alpha_PH12[idx_m, idx_o, 0] = np.sum(bars[bars['dim']==1]['death'] - \
                                                         bars[bars['dim']==1]['birth'])
                    alpha_PH12[idx_m, idx_o, 1] = np.max(bars[bars['dim']==1]['death'] - \
                                                         bars[bars['dim']==1]['birth'])
                    alpha_PH12[idx_m, idx_o, 2] = np.mean(bars[bars['dim']==1]['death'] - \
                                                          bars[bars['dim']==1]['birth'])
                    alpha_PH12[idx_m, idx_o, 3] = np.min(bars[bars['dim']==1]['birth'])
                    alpha_PH12[idx_m, idx_o, 4] = np.max(bars[bars['dim']==1]['birth'])
                    alpha_PH12[idx_m, idx_o, 5] = np.min(bars[bars['dim']==1]['death'])
                    alpha_PH12[idx_m, idx_o, 6] = np.max(bars[bars['dim']==1]['death'])
                if len(bars[bars['dim']==2]['death']) > 0:
                    alpha_PH12[idx_m, idx_o, 7]  = np.sum(bars[bars['dim']==2]['death'] - \
                                                          bars[bars['dim']==2]['birth'])
                    alpha_PH12[idx_m, idx_o, 8]  = np.max(bars[bars['dim']==2]['death'] - \
                                                          bars[bars['dim']==2]['birth'])
                    alpha_PH12[idx_m, idx_o, 9]  = np.mean(bars[bars['dim']==2]['death'] - \
                                                           bars[bars['dim']==2]['birth'])
                    alpha_PH12[idx_m, idx_o, 10] = np.min(bars[bars['dim']==2]['birth'])
                    alpha_PH12[idx_m, idx_o, 11] = np.max(bars[bars['dim']==2]['birth'])
                    alpha_PH12[idx_m, idx_o, 12] = np.min(bars[bars['dim']==2]['death'])
                    alpha_PH12[idx_m, idx_o, 13] = np.max(bars[bars['dim']==2]['death'])

        alpha_PH12_all = np.zeros([14])
        points = []
        for idx in range(EleLength):
            points += [iatom.pos for iatom in atoms_m[idx]]
            points += [iatom.pos for iatom in atoms_o[idx]]
        alpha_complex = gudhi.AlphaComplex(points=points)
        PH = alpha_complex.create_simplex_tree().persistence()

        tmpbars = np.zeros(len(PH), dtype=dt)
        cnt = 0
        for simplex in PH:
            dim, b, d = int(simplex[0]), float(simplex[1][0]), float(simplex[1][1])
            if d-b < 0.1: continue
            tmpbars[cnt]['dim']   = dim
            tmpbars[cnt]['birth'] = b
            tmpbars[cnt]['death'] = d
            cnt += 1
        bars = tmpbars[0:cnt]
        if len(bars[bars['dim']==1]['death']) > 0:
            alpha_PH12_all[0] = np.sum(bars[bars['dim']==1]['death'] - \
                                       bars[bars['dim']==1]['birth'])
            alpha_PH12_all[1] = np.max(bars[bars['dim']==1]['death'] - \
                                       bars[bars['dim']==1]['birth'])
            alpha_PH12_all[2] = np.mean(bars[bars['dim']==1]['death'] - \
                                        bars[bars['dim']==1]['birth'])
            alpha_PH12_all[3] = np.min(bars[bars['dim']==1]['birth'])
            alpha_PH12_all[4] = np.max(bars[bars['dim']==1]['birth'])
            alpha_PH12_all[5] = np.min(bars[bars['dim']==1]['death'])
            alpha_PH12_all[6] = np.max(bars[bars['dim']==1]['death'])
        if len(bars[bars['dim']==2]['death']) > 0:
            alpha_PH12_all[7]  = np.sum(bars[bars['dim']==2]['death'] - \
                                        bars[bars['dim']==2]['birth'])
            alpha_PH12_all[8]  = np.max(bars[bars['dim']==2]['death'] - \
                                        bars[bars['dim']==2]['birth'])
            alpha_PH12_all[9]  = np.mean(bars[bars['dim']==2]['death'] - \
                                         bars[bars['dim']==2]['birth'])
            alpha_PH12_all[10] = np.min(bars[bars['dim']==2]['birth'])
            alpha_PH12_all[11] = np.max(bars[bars['dim']==2]['birth'])
            alpha_PH12_all[12] = np.min(bars[bars['dim']==2]['death'])
            alpha_PH12_all[13] = np.max(bars[bars['dim']==2]['death'])

        return np.array(alpha_PH12), np.array(alpha_PH12_all)

    def FRI_dists(self, atoms_m, atoms_o):
        # get the list of all element-specific interactions distance
        FRI_dists = []
        for idx_m, e_m in enumerate(ElementList):
            for idx_o, e_o in enumerate(ElementList):
                dists = []
                for ii, iatom in enumerate(atoms_m[idx_m]):
                    for jj, jatom in enumerate(atoms_o[idx_o]):
                        dists.append(np.linalg.norm(iatom.pos-jatom.pos))
                dists = np.array(dists)
                FRI_dists.append(dists)
        return FRI_dists

    def FRI_Lorentz(self, dists, kappa, eta):
        Feature_FRI = np.zeros([EleLength, EleLength])
        for idx_m, e_m in enumerate(ElementList):
            for idx_o, e_o in enumerate(ElementList):
                if len(dists[idx_m*EleLength+idx_o]) > 0:
                    eta_i = eta[idx_m] + eta[idx_o]
                    Lorentz_array = np.true_divide(dists[idx_m*EleLength+idx_o], eta_i)
                    Lorentz_array = 1./(1.+np.power(Lorentz_array, kappa))
                    Feature_FRI[idx_m, idx_o] = np.sum(Lorentz_array)
                else:
                    Feature_FRI[idx_m, idx_o] = 0
        return np.around(Feature_FRI, 8).flatten()

    def FRI_Exp(self, dists, kappa, eta):
        Feature_FRI = np.zeros([EleLength, EleLength])
        for idx_m, e_m in enumerate(ElementList):
            for idx_o, e_o in enumerate(ElementList):
                if len(dists[idx_m*EleLength+idx_o]) > 0:
                    eta_i = eta[idx_m] + eta[idx_o]
                    Exp_array = np.true_divide(dists[idx_m*EleLength+idx_o], eta_i)
                    Exp_array = np.exp(-np.power(Exp_array, kappa))
                    Feature_FRI[idx_m, idx_o] = np.sum(Exp_array)
                else:
                    Feature_FRI[idx_m, idx_o] = 0
        return np.around(Feature_FRI, 8).flatten()

    def FRI_Lorentz_(self, dists, kappa, eta):
        Feature_FRI = np.zeros([EleLength, EleLength, 4])
        for idx_m, e_m in enumerate(ElementList):
            for idx_o, e_o in enumerate(ElementList):
                if len(dists[idx_m*EleLength+idx_o]) > 0:
                    eta_i = eta[idx_m] + eta[idx_o]
                    Lorentz_array = np.true_divide(dists[idx_m*EleLength+idx_o], eta_i)
                    Lorentz_array = 1./(1.+np.power(Lorentz_array, kappa))
                    Feature_FRI[idx_m, idx_o, 0] = np.sum(Lorentz_array)
                    Feature_FRI[idx_m, idx_o, 1] = np.min(Lorentz_array)
                    Feature_FRI[idx_m, idx_o, 2] = np.max(Lorentz_array)
                    Feature_FRI[idx_m, idx_o, 3] = np.mean(Lorentz_array)
                else:
                    Feature_FRI[idx_m, idx_o, 0] = 0
                    Feature_FRI[idx_m, idx_o, 1] = 0
                    Feature_FRI[idx_m, idx_o, 2] = 0
                    Feature_FRI[idx_m, idx_o, 3] = 0
        return np.around(Feature_FRI, 8).flatten()

    def FRI_Exp_(self, dists, kappa, eta):
        Feature_FRI = np.zeros([EleLength, EleLength, 4])
        for idx_m, e_m in enumerate(ElementList):
            for idx_o, e_o in enumerate(ElementList):
                if len(dists[idx_m*EleLength+idx_o]) > 0:
                    eta_i = eta[idx_m] + eta[idx_o]
                    Exp_array = np.true_divide(dists[idx_m*EleLength+idx_o], eta_i)
                    Exp_array = np.exp(-np.power(Exp_array, kappa))
                    Feature_FRI[idx_m, idx_o, 0] = np.sum(Exp_array)
                    Feature_FRI[idx_m, idx_o, 1] = np.min(Exp_array)
                    Feature_FRI[idx_m, idx_o, 2] = np.max(Exp_array)
                    Feature_FRI[idx_m, idx_o, 3] = np.mean(Exp_array)
                else:
                    Feature_FRI[idx_m, idx_o, 0] = 0
                    Feature_FRI[idx_m, idx_o, 1] = 0
                    Feature_FRI[idx_m, idx_o, 2] = 0
                    Feature_FRI[idx_m, idx_o, 3] = 0
        return np.around(Feature_FRI, 8).flatten()

    def flexibility_rigidy_index(self, atoms_m, atoms_o):
        Feature_FRI = np.zeros([EleLength, EleLength, 6])
        for idx_m, e_m in enumerate(ElementList):
            for idx_o, e_o in enumerate(ElementList):
                dists = []
                for ii, iatom in enumerate(atoms_m[idx_m]):
                    for jj, jatom in enumerate(atoms_o[idx_o]):
                        dists.append(np.linalg.norm(iatom.pos-jatom.pos))
                dists  = np.array(dists)
                dists0 = np.true_divide(dists, (ElementTau[idx_m]+ElementTau[idx_o])*0.5)
                dists1 = np.true_divide(dists, (ElementTau[idx_m]+ElementTau[idx_o]))
                dists2 = np.true_divide(dists, (ElementTau[idx_m]+ElementTau[idx_o])*2)
                # kernel exponential 0
                dists_exp0 = np.exp(-np.power(dists1, 2))
                Feature_FRI[idx_m, idx_o, 0] = np.sum(dists_exp0)
                # kernel exponential 1
                dists_exp1 = np.exp(-np.power(dists1, 15))
                Feature_FRI[idx_m, idx_o, 1] = np.sum(dists_exp1)
                # kernel exponential 2
                dists_exp2 = np.exp(-np.power(dists2, 15))
                Feature_FRI[idx_m, idx_o, 2] = np.sum(dists_exp2)
                # kernel lorentz 0
                dists_Lor0 = 1./(1.+np.power(dists0, 5))
                Feature_FRI[idx_m, idx_o, 3] = np.sum(dists_Lor0)
                # kernel lorentz 1
                dists_Lor1 = 1./(1.+np.power(dists1, 5))
                Feature_FRI[idx_m, idx_o, 4] = np.sum(dists_Lor1)
                # kernel lorentz 2
                dists_Lor2 = 1./(1.+np.power(dists2, 5))
                Feature_FRI[idx_m, idx_o, 5] = np.sum(dists_Lor2)

        return np.around(Feature_FRI, 8)

def construct_features_PH0(b_dth_WT, b_bar_WT, b_dth_MT, b_bar_MT,
                           m_dth_WT, m_bar_WT, m_dth_MT, m_bar_MT,
                           s_dth_WT, s_bar_WT, s_dth_MT, s_bar_MT):
    Feature_ph0 = np.concatenate((b_dth_MT.flatten(), b_dth_WT.flatten()))
    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), b_dth_MT.flatten()-b_dth_WT.flatten()))

    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), b_bar_MT.flatten()))
    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), b_bar_WT.flatten()))
    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), b_bar_MT.flatten()-b_bar_WT.flatten()))

    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), m_dth_MT.flatten()))
    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), m_dth_WT.flatten()))
    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), m_dth_MT.flatten()-m_dth_WT.flatten()))

    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), m_bar_MT.flatten()))
    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), m_bar_WT.flatten()))
    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), m_bar_MT.flatten()-m_bar_WT.flatten()))

    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), s_dth_MT.flatten()))
    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), s_dth_WT.flatten()))
    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), s_dth_MT.flatten()-s_dth_WT.flatten()))

    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), s_bar_MT.flatten()))
    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), s_bar_WT.flatten()))
    Feature_ph0 = np.concatenate((Feature_ph0.flatten(), s_bar_MT.flatten()-s_bar_WT.flatten()))

    return Feature_ph0


def construct_features_PH0_cnn(b_dth_WT, b_bar_WT, b_dth_MT, b_bar_MT, 
                               m_dth_WT, m_bar_WT, m_dth_MT, m_bar_MT,
                               s_dth_WT, s_bar_WT, s_dth_MT, s_bar_MT):
    Feature_ph0 = np.concatenate((b_dth_MT, b_dth_WT), axis=1)
    Feature_ph0 = np.concatenate((Feature_ph0, b_dth_MT-b_dth_WT), axis=1)

    Feature_ph0 = np.concatenate((Feature_ph0, b_bar_MT), axis=1)
    Feature_ph0 = np.concatenate((Feature_ph0, b_bar_WT), axis=1)
    Feature_ph0 = np.concatenate((Feature_ph0, b_bar_MT-b_bar_WT), axis=1)

    Feature_ph0 = np.concatenate((Feature_ph0, m_dth_MT), axis=1)
    Feature_ph0 = np.concatenate((Feature_ph0, m_dth_WT), axis=1)
    Feature_ph0 = np.concatenate((Feature_ph0, m_dth_MT-m_dth_WT), axis=1)

    Feature_ph0 = np.concatenate((Feature_ph0, m_bar_MT), axis=1)
    Feature_ph0 = np.concatenate((Feature_ph0, m_bar_WT), axis=1)
    Feature_ph0 = np.concatenate((Feature_ph0, m_bar_MT-m_bar_WT), axis=1)

    Feature_ph0 = np.concatenate((Feature_ph0, s_dth_MT), axis=1)
    Feature_ph0 = np.concatenate((Feature_ph0, s_dth_WT), axis=1)
    Feature_ph0 = np.concatenate((Feature_ph0, s_dth_MT-s_dth_WT), axis=1)

    Feature_ph0 = np.concatenate((Feature_ph0, s_bar_MT), axis=1)
    Feature_ph0 = np.concatenate((Feature_ph0, s_bar_WT), axis=1)
    Feature_ph0 = np.concatenate((Feature_ph0, s_bar_MT-s_bar_WT), axis=1)

    return Feature_ph0

def construct_features_PH12(b_alpha_WT, b_alpha_all_WT, b_alpha_MT, b_alpha_all_MT, 
                            m_alpha_WT, m_alpha_all_WT, m_alpha_MT, m_alpha_all_MT,
                            s_alpha_WT, s_alpha_all_WT, s_alpha_MT, s_alpha_all_MT):
    Feature_ph12 = np.concatenate((b_alpha_MT.flatten(), b_alpha_WT.flatten()))
    Feature_ph12 = np.concatenate((Feature_ph12, b_alpha_MT.flatten()-b_alpha_WT.flatten()))

    Feature_ph12 = np.concatenate((Feature_ph12, b_alpha_all_MT.flatten()))
    Feature_ph12 = np.concatenate((Feature_ph12, b_alpha_all_WT.flatten()))
    Feature_ph12 = np.concatenate((Feature_ph12, b_alpha_all_MT.flatten()-b_alpha_all_WT.flatten()))

    Feature_ph12 = np.concatenate((Feature_ph12, m_alpha_MT.flatten()))
    Feature_ph12 = np.concatenate((Feature_ph12, m_alpha_WT.flatten()))
    Feature_ph12 = np.concatenate((Feature_ph12, m_alpha_MT.flatten()-m_alpha_WT.flatten()))

    Feature_ph12 = np.concatenate((Feature_ph12, m_alpha_all_MT.flatten()))
    Feature_ph12 = np.concatenate((Feature_ph12, m_alpha_all_WT.flatten()))
    Feature_ph12 = np.concatenate((Feature_ph12, m_alpha_all_MT.flatten()-m_alpha_all_WT.flatten()))

    Feature_ph12 = np.concatenate((Feature_ph12, s_alpha_MT.flatten()))
    Feature_ph12 = np.concatenate((Feature_ph12, s_alpha_WT.flatten()))
    Feature_ph12 = np.concatenate((Feature_ph12, s_alpha_MT.flatten()-s_alpha_WT.flatten()))

    Feature_ph12 = np.concatenate((Feature_ph12, s_alpha_all_MT.flatten()))
    Feature_ph12 = np.concatenate((Feature_ph12, s_alpha_all_WT.flatten()))
    Feature_ph12 = np.concatenate((Feature_ph12, s_alpha_all_MT.flatten()-s_alpha_all_WT.flatten()))

    return Feature_ph12

def construct_features_FRI(c_WT,          c_MT,
                           c_WT_dist_b,   c_MT_dist_b,   
                           c_WT_dist_m_o, c_MT_dist_m_o,
                           c_WT_dist_m_s, c_MT_dist_m_s):
    def feature_concatenate(c_WT_b, c_MT_b, c_WT_m_o, c_MT_m_o, c_WT_m_s, c_MT_m_s):
        feature = np.concatenate((c_MT_b, c_WT_b))
        feature = np.concatenate((feature, c_MT_b-c_WT_b))

        feature = np.concatenate((feature, c_MT_m_o))
        feature = np.concatenate((feature, c_WT_m_o))
        feature = np.concatenate((feature, c_MT_m_o-c_WT_m_o))

        feature = np.concatenate((feature, c_MT_m_s))
        feature = np.concatenate((feature, c_WT_m_s))
        feature = np.concatenate((feature, c_MT_m_s-c_WT_m_s))
        return feature

    kappa = 2; ElementTau = [5, 2*1.01, 2]
    c_WT_FRI_Exp_b   = c_WT.FRI_Exp_(c_WT_dist_b,   kappa, ElementTau)
    c_WT_FRI_Exp_m_o = c_WT.FRI_Exp_(c_WT_dist_m_o, kappa, ElementTau)
    c_WT_FRI_Exp_m_s = c_WT.FRI_Exp_(c_WT_dist_m_s, kappa, ElementTau)
    c_MT_FRI_Exp_b   = c_MT.FRI_Exp_(c_MT_dist_b,   kappa, ElementTau)
    c_MT_FRI_Exp_m_o = c_MT.FRI_Exp_(c_MT_dist_m_o, kappa, ElementTau)
    c_MT_FRI_Exp_m_s = c_MT.FRI_Exp_(c_MT_dist_m_s, kappa, ElementTau)
    feature_Exp = feature_concatenate(c_WT_FRI_Exp_b,   c_MT_FRI_Exp_b,
                                      c_WT_FRI_Exp_m_o, c_MT_FRI_Exp_m_o,
                                      c_WT_FRI_Exp_m_s, c_MT_FRI_Exp_m_s)

    kappa = 4; ElementTau = [1, 6*1.01, 6]
    c_WT_FRI_Lorentz_b   = c_WT.FRI_Lorentz_(c_WT_dist_b,   kappa, ElementTau)
    c_WT_FRI_Lorentz_m_o = c_WT.FRI_Lorentz_(c_WT_dist_m_o, kappa, ElementTau)
    c_WT_FRI_Lorentz_m_s = c_WT.FRI_Lorentz_(c_WT_dist_m_s, kappa, ElementTau)
    c_MT_FRI_Lorentz_b   = c_MT.FRI_Lorentz_(c_MT_dist_b,   kappa, ElementTau)
    c_MT_FRI_Lorentz_m_o = c_MT.FRI_Lorentz_(c_MT_dist_m_o, kappa, ElementTau)
    c_MT_FRI_Lorentz_m_s = c_MT.FRI_Lorentz_(c_MT_dist_m_s, kappa, ElementTau)
    feature_Lorentz = feature_concatenate(c_WT_FRI_Lorentz_b,   c_MT_FRI_Lorentz_b,
                                          c_WT_FRI_Lorentz_m_o, c_MT_FRI_Lorentz_m_o,
                                          c_WT_FRI_Lorentz_m_s, c_MT_FRI_Lorentz_m_s)

    Feature_FRI = np.concatenate((feature_Exp, feature_Lorentz))
    return Feature_FRI

def construct_features_FRI_(c_WT,          c_MT,
                           c_WT_dist_b,   c_MT_dist_b,   
                           c_WT_dist_m_o, c_MT_dist_m_o,
                           c_WT_dist_m_s, c_MT_dist_m_s):
    def feature_concatenate(c_WT_b, c_MT_b, c_WT_m_o, c_MT_m_o, c_WT_m_s, c_MT_m_s):
        feature = np.concatenate((c_MT_b, c_WT_b))
        feature = np.concatenate((feature, c_MT_b-c_WT_b))

        feature = np.concatenate((feature, c_MT_m_o))
        feature = np.concatenate((feature, c_WT_m_o))
        feature = np.concatenate((feature, c_MT_m_o-c_WT_m_o))

        feature = np.concatenate((feature, c_MT_m_s))
        feature = np.concatenate((feature, c_WT_m_s))
        feature = np.concatenate((feature, c_MT_m_s-c_WT_m_s))
        return feature

    kappa = 2; ElementTau = [5, 2*1.01, 2]
    c_WT_FRI_Exp_b   = c_WT.FRI_Exp_(c_WT_dist_b,   kappa, ElementTau)
    c_WT_FRI_Exp_m_o = c_WT.FRI_Exp_(c_WT_dist_m_o, kappa, ElementTau)
    c_WT_FRI_Exp_m_s = c_WT.FRI_Exp_(c_WT_dist_m_s, kappa, ElementTau)
    c_MT_FRI_Exp_b   = c_MT.FRI_Exp_(c_MT_dist_b,   kappa, ElementTau)
    c_MT_FRI_Exp_m_o = c_MT.FRI_Exp_(c_MT_dist_m_o, kappa, ElementTau)
    c_MT_FRI_Exp_m_s = c_MT.FRI_Exp_(c_MT_dist_m_s, kappa, ElementTau)
    feature_Exp = feature_concatenate(c_WT_FRI_Exp_b,   c_MT_FRI_Exp_b,
                                      c_WT_FRI_Exp_m_o, c_MT_FRI_Exp_m_o,
                                      c_WT_FRI_Exp_m_s, c_MT_FRI_Exp_m_s)

    kappa = 4; ElementTau = [1, 6*1.01, 6]
    c_WT_FRI_Lorentz_b   = c_WT.FRI_Lorentz_(c_WT_dist_b,   kappa, ElementTau)
    c_WT_FRI_Lorentz_m_o = c_WT.FRI_Lorentz_(c_WT_dist_m_o, kappa, ElementTau)
    c_WT_FRI_Lorentz_m_s = c_WT.FRI_Lorentz_(c_WT_dist_m_s, kappa, ElementTau)
    c_MT_FRI_Lorentz_b   = c_MT.FRI_Lorentz_(c_MT_dist_b,   kappa, ElementTau)
    c_MT_FRI_Lorentz_m_o = c_MT.FRI_Lorentz_(c_MT_dist_m_o, kappa, ElementTau)
    c_MT_FRI_Lorentz_m_s = c_MT.FRI_Lorentz_(c_MT_dist_m_s, kappa, ElementTau)
    feature_Lorentz = feature_concatenate(c_WT_FRI_Lorentz_b,   c_MT_FRI_Lorentz_b,
                                          c_WT_FRI_Lorentz_m_o, c_MT_FRI_Lorentz_m_o,
                                          c_WT_FRI_Lorentz_m_s, c_MT_FRI_Lorentz_m_s)

    Feature_FRI = np.concatenate((feature_Exp, feature_Lorentz))
    return Feature_FRI # construct_features_FRI_

if __name__ == '__main__':
    from PPIstructure import get_structure
    import time
    s = get_structure(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6], sys.argv[7])
    s.generateMutedPartnerPDBs()
    s.generateMutedPartnerPQRs()
    s.generateComplexPDBs()
    #s.readFASTA()
    #s.writeFASTA()

    s_time = time.time()
    c_WT = pro_complex(s, 'WT')
    c_WT_b_r_dth, c_WT_b_r_bar = c_WT.rips_complex(c_WT.atoms_b_m, c_WT.atoms_b_o)
    c_WT_m_r_dth, c_WT_m_r_bar = c_WT.rips_complex(c_WT.atoms_m_m, c_WT.atoms_m_o)
    c_WT_s_r_dth, c_WT_s_r_bar = c_WT.rips_complex(c_WT.atoms_m_m, c_WT.atoms_m_s)

    c_MT = pro_complex(s, 'MT')
    c_MT_b_r_dth, c_MT_b_r_bar = c_MT.rips_complex(c_MT.atoms_b_m, c_MT.atoms_b_o)
    c_MT_m_r_dth, c_MT_m_r_bar = c_MT.rips_complex(c_MT.atoms_m_m, c_MT.atoms_m_o)
    c_MT_s_r_dth, c_MT_s_r_bar = c_MT.rips_complex(c_MT.atoms_m_m, c_MT.atoms_m_s)
    feature_PH0 = construct_features_PH0(c_WT_b_r_dth, c_WT_b_r_bar, c_MT_b_r_dth, c_MT_b_r_bar, 
                                         c_WT_m_r_dth, c_WT_m_r_bar, c_MT_m_r_dth, c_MT_m_r_bar,
                                         c_WT_s_r_dth, c_WT_s_r_bar, c_MT_s_r_dth, c_MT_s_r_bar)
    print(feature_PH0.shape)

    #c_WT_dist_b   = c_WT.FRI_dists(c_WT.atoms_b_m, c_WT.atoms_b_o)
    #c_WT_dist_m_o = c_WT.FRI_dists(c_WT.atoms_m_m, c_WT.atoms_m_o)
    #c_WT_dist_m_s = c_WT.FRI_dists(c_WT.atoms_m_m, c_WT.atoms_m_s)

    #c_MT_dist_b   = c_MT.FRI_dists(c_MT.atoms_b_m, c_MT.atoms_b_o)
    #c_MT_dist_m_o = c_MT.FRI_dists(c_MT.atoms_m_m, c_MT.atoms_m_o)
    #c_MT_dist_m_s = c_MT.FRI_dists(c_MT.atoms_m_m, c_MT.atoms_m_s)
    #feature_FRI  = construct_features_FRI(c_WT,          c_MT,
    #                                      c_WT_dist_b,   c_MT_dist_b,
    #                                      c_WT_dist_m_o, c_MT_dist_m_o,
    #                                      c_WT_dist_m_s, c_MT_dist_m_s)
    print(feature_FRI.shape)
    e_time = time.time()
    print(e_time-s_time)
    #c_WT_b_rips_dth, c_WT_b_rips_bar = c_WT.rips_complex(c_WT.atoms_b_m, c_WT.atoms_b_o, birth_cut=3.)
    #c_WT_m_rips_dth, c_WT_m_rips_bar = c_WT.rips_complex(c_WT.atoms_m_m, c_WT.atoms_m_o)
    #c_WT_s_rips_dth, c_WT_s_rips_bar = c_WT.rips_complex(c_WT.atoms_m_m, c_WT.atoms_m_s)
    #c_WT_b_alpha, c_WT_b_alpha_all = c_WT.alpha_shape(c_WT.atoms_b_m, c_WT.atoms_b_o)
    #c_WT_m_alpha, c_WT_m_alpha_all = c_WT.alpha_shape(c_WT.atoms_m_m, c_WT.atoms_m_o)
    #c_WT_s_alpha, c_WT_s_alpha_all = c_WT.alpha_shape(c_WT.atoms_m_m, c_WT.atoms_m_s)
    #c_WT_m_FRI = c_WT.flexibility_rigidy_index(c_WT.atoms_m_m, c_WT.atoms_m_o)
    #c_WT_s_FRI = c_WT.flexibility_rigidy_index(c_WT.atoms_m_m, c_WT.atoms_m_s)
    #c_WT_dist_m_o = c_WT.FRI_dists(c_WT.atoms_m_m, c_WT.atoms_m_o)
    #c_WT_dist_m_s = c_WT.FRI_dists(c_WT.atoms_m_m, c_WT.atoms_m_s)

    c_MT = pro_complex('1DVF', 'CD', 'D', 'A', 52)
    c_MT.loadBindingPDB('1DVF_AB_CD_MT')
    c_MT.loadMutantPDB('1DVF_AB_CD_MT')
    tic = time.time()
    b_PGS_MT = c_MT.rips_complex_spectra(c_MT.atoms_b_m, c_MT.atoms_b_o)
    m_PGS_MT = c_MT.rips_complex_spectra(c_MT.atoms_m_m, c_MT.atoms_m_o)
    toc = time.time()
    print(toc-tic)
    construct_features_PGS0(b_PGS_WT, b_PGS_MT, m_PGS_WT, m_PGS_MT)
    #c_MT_b_rips_dth, c_MT_b_rips_bar = c_MT.rips_complex(c_MT.atoms_b_m, c_MT.atoms_b_o)
    #c_MT_m_rips_dth, c_MT_m_rips_bar = c_MT.rips_complex(c_MT.atoms_m_m, c_MT.atoms_m_o)
    #c_MT_s_rips_dth, c_MT_s_rips_bar = c_MT.rips_complex(c_MT.atoms_m_m, c_MT.atoms_m_s)
    #c_MT_b_alpha, c_MT_b_alpha_all = c_MT.alpha_shape(c_MT.atoms_b_m, c_MT.atoms_b_o)
    #c_MT_m_alpha, c_MT_m_alpha_all = c_MT.alpha_shape(c_MT.atoms_m_m, c_MT.atoms_m_o)
    #c_MT_s_alpha, c_MT_s_alpha_all = c_MT.alpha_shape(c_MT.atoms_m_m, c_MT.atoms_m_s)
    #c_MT_m_FRI = c_MT.flexibility_rigidy_index(c_MT.atoms_m_m, c_MT.atoms_m_o)
    #c_MT_s_FRI = c_MT.flexibility_rigidy_index(c_MT.atoms_m_m, c_MT.atoms_m_s)
    #c_MT_dist_m_o = c_MT.FRI_dists(c_MT.atoms_m_m, c_MT.atoms_m_o)
    #c_MT_dist_m_s = c_MT.FRI_dists(c_MT.atoms_m_m, c_MT.atoms_m_s)
    #print(c_WT.FRI_Exp(c_WT_dist_m_o, 2, ElementTau)-c_MT.FRI_Exp(c_MT_dist_m_o, 2, ElementTau))
    #print(c_WT.FRI_Exp(c_WT_dist_m_o, 2, ElementTau)-c_MT.FRI_Exp(c_MT_dist_m_o, 2, ElementTau))

    #construct_features_PH0(c_WT_b_rips_dth, c_WT_b_rips_bar, c_MT_b_rips_dth, c_MT_b_rips_bar, 
    #                       c_WT_m_rips_dth, c_WT_m_rips_bar, c_MT_m_rips_dth, c_MT_m_rips_bar,
    #                       c_WT_s_rips_dth, c_WT_s_rips_bar, c_MT_s_rips_dth, c_MT_s_rips_bar)
    #construct_features_PH12(c_WT_b_alpha, c_WT_b_alpha_all, c_MT_b_alpha, c_MT_b_alpha_all, 
    #                        c_WT_m_alpha, c_WT_m_alpha_all, c_MT_m_alpha, c_MT_m_alpha_all,
    #                        c_WT_s_alpha, c_WT_s_alpha_all, c_MT_s_alpha, c_MT_s_alpha_all)
    #construct_features_FRI(c_WT_m_FRI, c_MT_m_FRI, c_WT_s_FRI, c_MT_s_FRI)
