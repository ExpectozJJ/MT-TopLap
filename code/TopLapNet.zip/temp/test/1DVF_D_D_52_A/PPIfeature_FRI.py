import sys, os
import numpy as np
from PPIstructure import get_structure
from PPIcomplex import pro_complex

def feature_concatenate(c_WT_b, c_MT_b, c_WT_m_o, c_MT_m_o, c_WT_m_s, c_MT_m_s):
    feature = np.concatenate((c_MT_b, c_WT_b))
    feature = np.concatenate((feature, c_MT_b-c_WT_b))

    feature = np.concatenate((feature, c_MT_m_o))
    feature = np.concatenate((feature, c_WT_m_o))
    feature = np.concatenate((feature, c_MT_m_o-c_WT_m_o))

    feature = np.concatenate((feature, c_MT_m_s))
    feature = np.concatenate((feature, c_WT_m_s))
    feature = np.concatenate((feature, c_MT_m_s-c_WT_m_s))
    return feature

# 1DVF AB CD D D 52 A 7.0
#          arguement    example
PDBid    = sys.argv[1] # 1KBH
Antibody = sys.argv[2] # A
Antigen  = sys.argv[3] # B
Chain    = sys.argv[4] # A
resWT    = sys.argv[5] # L
resID    = sys.argv[6] # 37
resMT    = sys.argv[7] # W
pH       = sys.argv[8] # 7.0

# setup PDB_files and other files
s = get_structure(PDBid, Antibody, Antigen, Chain, resWT, resID, resMT, pH)

# setup and compute complex information
c_WT = pro_complex(PDBid, s.targetChains, Chain, resWT, s.resID)
c_WT.loadBindingPDB(s.fileComplex+'_WT')
c_WT.loadMutantPDB(s.fileComplex+'_WT')
c_WT_dist_b   = c_WT.FRI_dists(c_WT.atoms_b_m, c_WT.atoms_b_o)
c_WT_dist_m_o = c_WT.FRI_dists(c_WT.atoms_m_m, c_WT.atoms_m_o)
c_WT_dist_m_s = c_WT.FRI_dists(c_WT.atoms_m_m, c_WT.atoms_m_s)

c_MT = pro_complex(PDBid, s.targetChains, Chain, resMT, s.resID)
c_MT.loadBindingPDB(s.fileComplex+'_MT')
c_MT.loadMutantPDB(s.fileComplex+'_MT')
c_MT_dist_b   = c_MT.FRI_dists(c_MT.atoms_b_m, c_MT.atoms_b_o)
c_MT_dist_m_o = c_MT.FRI_dists(c_MT.atoms_m_m, c_MT.atoms_m_o)
c_MT_dist_m_s = c_MT.FRI_dists(c_MT.atoms_m_m, c_MT.atoms_m_s)

# generate FRI features
feature_Exp_ttl = []
feature_Lorentz_ttl = []
kappas = np.linspace(0.5, 5.0, 10)
ElementTauC = ElementTauO = np.linspace(1, 16, 16)
for idx, ikappa in enumerate(kappas):
    for jdx, iTauC in enumerate(ElementTauC):
        for kdx, iTauO in enumerate(ElementTauO):
            ElementTau = np.array([iTauC, iTauO*1.01, iTauO])
 
            c_WT_FRI_Exp_b   = c_WT.FRI_Exp(c_WT_dist_b,   ikappa, ElementTau)
            c_WT_FRI_Exp_m_o = c_WT.FRI_Exp(c_WT_dist_m_o, ikappa, ElementTau)
            c_WT_FRI_Exp_m_s = c_WT.FRI_Exp(c_WT_dist_m_s, ikappa, ElementTau)
 
            c_MT_FRI_Exp_b   = c_MT.FRI_Exp(c_MT_dist_b,   ikappa, ElementTau)
            c_MT_FRI_Exp_m_o = c_MT.FRI_Exp(c_MT_dist_m_o, ikappa, ElementTau)
            c_MT_FRI_Exp_m_s = c_MT.FRI_Exp(c_MT_dist_m_s, ikappa, ElementTau)
 
            feature_Exp = feature_concatenate(c_WT_FRI_Exp_b,   c_MT_FRI_Exp_b,
                                              c_WT_FRI_Exp_m_o, c_MT_FRI_Exp_m_o,
                                              c_WT_FRI_Exp_m_s, c_MT_FRI_Exp_m_s)
            feature_Exp_i = feature_concatenate(c_MT_FRI_Exp_b,   c_WT_FRI_Exp_b,
                                                c_MT_FRI_Exp_m_o, c_WT_FRI_Exp_m_o,
                                                c_MT_FRI_Exp_m_s, c_WT_FRI_Exp_m_s)
            feature_Exp_ttl.append(feature_Exp)
            feature_Exp_ttl.append(feature_Exp_i)

            c_WT_FRI_Lorentz_b   = c_WT.FRI_Lorentz(c_WT_dist_b,   ikappa, ElementTau)
            c_WT_FRI_Lorentz_m_o = c_WT.FRI_Lorentz(c_WT_dist_m_o, ikappa, ElementTau)
            c_WT_FRI_Lorentz_m_s = c_WT.FRI_Lorentz(c_WT_dist_m_s, ikappa, ElementTau)

            c_MT_FRI_Lorentz_b   = c_MT.FRI_Lorentz(c_MT_dist_b,   ikappa, ElementTau)
            c_MT_FRI_Lorentz_m_o = c_MT.FRI_Lorentz(c_MT_dist_m_o, ikappa, ElementTau)
            c_MT_FRI_Lorentz_m_s = c_MT.FRI_Lorentz(c_MT_dist_m_s, ikappa, ElementTau)

            feature_Lorentz = feature_concatenate(c_WT_FRI_Lorentz_b,   c_MT_FRI_Lorentz_b,
                                                  c_WT_FRI_Lorentz_m_o, c_MT_FRI_Lorentz_m_o,
                                                  c_WT_FRI_Lorentz_m_s, c_MT_FRI_Lorentz_m_s)
            feature_Lorentz_i = feature_concatenate(c_MT_FRI_Lorentz_b,   c_WT_FRI_Lorentz_b,
                                                    c_MT_FRI_Lorentz_m_o, c_WT_FRI_Lorentz_m_o,
                                                    c_MT_FRI_Lorentz_m_s, c_WT_FRI_Lorentz_m_s)
            feature_Lorentz_ttl.append(feature_Lorentz)
            feature_Lorentz_ttl.append(feature_Lorentz_i)
filename_Exp = PDBid+'_'+Chain+'_'+resWT+'_'+resID+'_'+resMT+'_Exp.npy'
OutFile = open(filename_Exp, 'wb')
np.save(OutFile, filename_Exp)
OutFile.close()

filename_Lorentz = PDBid+'_'+Chain+'_'+resWT+'_'+resID+'_'+resMT+'_Lorentz.npy'
OutFile = open(filename_Lorentz, 'wb')
np.save(OutFile, filename_Lorentz)
OutFile.close()
