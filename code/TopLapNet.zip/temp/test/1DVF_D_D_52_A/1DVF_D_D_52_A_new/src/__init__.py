from .prot import PyProtein
