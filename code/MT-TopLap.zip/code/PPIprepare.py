#!/mnt/home/chenj159/anaconda3/bin/python
import sys, os
import numpy as np
from PPIstructure import get_structure
from PPIprotein import protein

# 1DVF AB CD D D 52 A 7.0
#          arguement    example
PDBid    = sys.argv[1] # 1KBH
Antibody = sys.argv[2] # A
Antigen  = sys.argv[3] # B
Chain    = sys.argv[4] # A
resWT    = sys.argv[5] # L
resID    = sys.argv[6] # 37
resMT    = sys.argv[7] # W
pH       = sys.argv[8] # 7.0

s = get_structure(PDBid, Antibody, Antigen, Chain, resWT, resID, resMT, pH=pH, onlyBLAST=True)
s.readFASTA()
s.writeFASTA()
#########################################################################################
p_WT = protein(s, 'WT', onlyBLAST=True)
p_WT.runBLAST()

#----------------------------------------------------------------------------------------
p_MT = protein(s, 'MT', onlyBLAST=True)
p_MT.runBLAST()
