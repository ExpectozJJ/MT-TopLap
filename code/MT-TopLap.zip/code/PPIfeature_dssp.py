#!/mnt/home/chenj159/anaconda3/bin/python
import sys, os
import numpy as np
from PPIstructure import get_structure
from PPIprotein import protein
from PPIprotein import construct_feature_aux
from PPIcomplex import pro_complex
from PPIcomplex import construct_features_PH0
from PPIcomplex import construct_features_PH12
from PPIcomplex import construct_features_FRI

# 1DVF AB CD D D 52 A 7.0
#          arguement    example
PDBid    = sys.argv[1] # 1KBH
Antibody = sys.argv[2] # A
Antigen  = sys.argv[3] # B
Chain    = sys.argv[4] # A
resWT    = sys.argv[5] # L
resID    = sys.argv[6] # 37
resMT    = sys.argv[7] # W
pH       = sys.argv[8] # 7.0

s = get_structure(PDBid, Antibody, Antigen, Chain, resWT, resID, resMT, pH=pH)
s.generateMutedPartnerPDBs()
s.generateMutedPartnerPQRs()
s.generateComplexPDBs()
s.readFASTA()
s.writeFASTA()
#########################################################################################
p_WT = protein(s, 'WT')
p_WT.construct_feature_seq()
#----------------------------------------------------------------------------------------
p_MT = protein(s, 'MT')
p_MT.construct_feature_seq()
