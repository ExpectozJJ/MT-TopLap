#!/mnt/home/chenj159/anaconda3/bin/python
import sys, os
import numpy as np
from PPIstructure import get_structure
from PPIcomplex import pro_complex
from PPIcomplex import construct_features_PH0
from PPIcomplex import construct_features_PH12
from PPIcomplex import construct_features_FRI

# 1DVF AB CD D D 52 A 7.0
#          arguement    example
PDBid    = sys.argv[1] # 1KBH
Antibody = sys.argv[2] # A
Antigen  = sys.argv[3] # B
Chain    = sys.argv[4] # A
resWT    = sys.argv[5] # L
resID    = sys.argv[6] # 37
resMT    = sys.argv[7] # W
pH       = sys.argv[8] # 7.0

flag_BLAST = False
flag_MIBPB = False

s = get_structure(PDBid, Antibody, Antigen, Chain, resWT, resID, resMT, pH=pH)
s.generateComplexPDBs()
#########################################################################################
c_WT = pro_complex(s, 'WT')
c_WT_Lap_b = c_WT.rips_complex_spectra(c_WT.atoms_b_m, c_WT.atoms_b_o)
#c_WT_Lap_m = c_WT.rips_complex_spectra(c_WT.atoms_m_m, c_WT.atoms_m_o)
#c_WT_Lap_s = c_WT.rips_complex_spectra(c_WT.atoms_m_m, c_WT.atoms_m_s)
#----------------------------------------------------------------------------------------
c_MT = pro_complex(s, 'MT')
c_MT_Lap_b = c_MT.rips_complex_spectra(c_MT.atoms_b_m, c_MT.atoms_b_o)
#c_MT_Lap_m = c_MT.rips_complex_spectra(c_MT.atoms_m_m, c_MT.atoms_m_o)
#c_MT_Lap_s = c_MT.rips_complex_spectra(c_MT.atoms_m_m, c_MT.atoms_m_s)
#----------------------------------------------------------------------------------------
feature_Lap_b = np.concatenate((c_MT_Lap_b, c_WT_Lap_b), axis=0)
feature_Lap_b = np.concatenate((feature_Lap_b, c_MT_Lap_b-c_WT_Lap_b), axis=0)
#feature_Lap_m = np.concatenate((c_MT_Lap_m, c_WT_Lap_m), axis=0)
#feature_Lap_m = np.concatenate((feature_Lap_m, c_MT_Lap_m-c_WT_Lap_m), axis=0)
#feature_Lap_s = np.concatenate((c_MT_Lap_s, c_WT_Lap_s), axis=0)
#feature_Lap_s = np.concatenate((feature_Lap_s, c_MT_Lap_s-c_WT_Lap_s), axis=0)
#feature_Lap   = np.concatenate((feature_Lap_b, feature_Lap_m), axis=0)
#feature_Lap   = np.concatenate((feature_Lap,   feature_Lap_s), axis=0)
#----------------------------------------------------------------------------------------
feature_Lap_b_inv = np.concatenate((c_WT_Lap_b, c_MT_Lap_b), axis=0)
feature_Lap_b_inv = np.concatenate((feature_Lap_b_inv, c_WT_Lap_b-c_MT_Lap_b), axis=0)
#feature_Lap_m_inv = np.concatenate((c_WT_Lap_m, c_MT_Lap_m), axis=0)
#feature_Lap_m_inv = np.concatenate((feature_Lap_m_inv, c_WT_Lap_m-c_MT_Lap_m), axis=0)
#feature_Lap_s_inv = np.concatenate((c_WT_Lap_s, c_MT_Lap_s), axis=0)
#feature_Lap_s_inv = np.concatenate((feature_Lap_s_inv, c_WT_Lap_s-c_MT_Lap_s), axis=0)
#feature_Lap_inv   = np.concatenate((feature_Lap_b_inv, feature_Lap_m_inv), axis=0)
#feature_Lap_inv   = np.concatenate((feature_Lap_inv,   feature_Lap_s_inv), axis=0)
#########################################################################################
print('Lap feature size: ', feature_Lap_b.shape)

filename = PDBid+'_'+Chain+'_'+resWT+'_'+resID+'_'+resMT
OutFile = open(filename+'_Lap_b.npy', 'wb')
np.save(OutFile, feature_Lap_b)
OutFile.close()

filename_inv = PDBid+'_'+Chain+'_'+resMT+'_'+resID+'_'+resWT
OutFile = open(filename_inv+'_Lap_b.npy', 'wb')
np.save(OutFile, feature_Lap_b_inv)
OutFile.close()
#########################################################################################
