## TopLapNet

### Installation
At `bin`, change the directory of `jackal.dir` to your local path.
```shell
$ cd code
$ python setup.py build_ext -i
$ cd ..
$ cd test/1NCA_H_N_31_Q
$ ln -s ../../bin/jackal.dir jackal.dir
$ ln -s ../../bin/profix profix
$ ln -s ../../bin/scap scap
$ ln -s ../../code/PPIstructure.py PPIstructure.py
$ ln -s ../../code/PPIprotein.py PPIprotein.py
$ ln -s ../../code/src src
```

You may also use 
```shell
$ pip install -e . -v
```
to install the package.

### Run
```shell
$ python PPIstructure.py 1NCA LH N H N 31 Q
$ python PPIprotein.py 1NCA LH N H N 31 Q
```
