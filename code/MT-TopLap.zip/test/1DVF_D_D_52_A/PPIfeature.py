import sys, os
import numpy as np
from PPIstructure import get_structure
from PPIprotein import protein
from PPIprotein import construct_features_aux
from PPIcomplex import pro_complex
from PPIcomplex import construct_features_PH0
from PPIcomplex import construct_features_PH12
from PPIcomplex import construct_features_FRI

# 1DVF AB CD D D 52 A 7.0
#          arguement    example
PDBid    = sys.argv[1] # 1KBH
Antibody = sys.argv[2] # A
Antigen  = sys.argv[3] # B
Chain    = sys.argv[4] # A
resWT    = sys.argv[5] # L
resID    = sys.argv[6] # 37
resMT    = sys.argv[7] # W
pH       = sys.argv[8] # 7.0

s = get_structure(PDBid, Antibody, Antigen, Chain, resWT, resID, resMT, pH)
filename = PDBid+'_'+Chain+'_'+resWT+'_'+resID+'_'+resMT
filename_inv = PDBid+'_'+Chain+'_'+resMT+'_'+resID+'_'+resWT
#########################################################################################
if not os.path.exists(filename+'_aux.npy') or not os.path.exists(filename_inv+'_aux.npy'):
    p_WT = protein(PDBid, s.targetChains, Chain, resWT, s.resID, pH, s.ResIDSeq, s.fasta_WT, 'WT')
    p_WT.loadPQRFile()
    p_WT.construct_index_list()
    p_WT.setup_pairwise_interaction()
    p_WT.runMIBPB()
    p_WT.construct_feature()
    p_WT.get_pka_info()
    p_WT.construct_environment_feature()
    p_WT.runBLAST()
    p_WT.secondary_structure()
    #----------------------------------------------------------------------------------------
    p_MT = protein(PDBid, s.targetChains, Chain, resMT, s.resID, pH, s.ResIDSeq, s.fasta_MT, 'MT')
    p_MT.loadPQRFile()
    p_MT.construct_index_list()
    p_MT.setup_pairwise_interaction()
    p_MT.runMIBPB()
    p_MT.construct_feature()
    p_MT.get_pka_info()
    p_MT.construct_environment_feature()
    p_MT.runBLAST()
    p_MT.secondary_structure()
    #----------------------------------------------------------------------------------------
    feature_aux = construct_features_aux(p_WT, p_MT)
    feature_aux_inv = construct_features_aux(p_MT, p_WT)
else:
    feature_aux = np.load(filename+'_aux.npy')[:759]
    feature_aux_inv = np.load(filename_inv+'_aux.npy')[:759]
#########################################################################################
c_WT = pro_complex(PDBid, s.targetChains, Chain, resWT, s.resID)
c_WT.loadBindingPDB(s.fileComplex+'_WT')
c_WT.loadMutantPDB(s.fileComplex+'_WT')

c_WT_b_r_dth, c_WT_b_r_bar = c_WT.rips_complex(c_WT.atoms_b_m, c_WT.atoms_b_o)
c_WT_m_r_dth, c_WT_m_r_bar = c_WT.rips_complex(c_WT.atoms_m_m, c_WT.atoms_m_o)
c_WT_s_r_dth, c_WT_s_r_bar = c_WT.rips_complex(c_WT.atoms_m_m, c_WT.atoms_m_s)

c_WT_b_a, c_WT_b_a_all = c_WT.alpha_shape(c_WT.atoms_b_m, c_WT.atoms_b_o)
c_WT_m_a, c_WT_m_a_all = c_WT.alpha_shape(c_WT.atoms_m_m, c_WT.atoms_m_o)
c_WT_s_a, c_WT_s_a_all = c_WT.alpha_shape(c_WT.atoms_m_m, c_WT.atoms_m_s)

c_WT_dist_b   = c_WT.FRI_dists(c_WT.atoms_b_m, c_WT.atoms_b_o)
c_WT_dist_m_o = c_WT.FRI_dists(c_WT.atoms_m_m, c_WT.atoms_m_o)
c_WT_dist_m_s = c_WT.FRI_dists(c_WT.atoms_m_m, c_WT.atoms_m_s)
#----------------------------------------------------------------------------------------
c_MT = pro_complex(PDBid, s.targetChains, Chain, resMT, s.resID)
c_MT.loadBindingPDB(s.fileComplex+'_MT')
c_MT.loadMutantPDB(s.fileComplex+'_MT')

c_MT_b_r_dth, c_MT_b_r_bar = c_MT.rips_complex(c_MT.atoms_b_m, c_MT.atoms_b_o)
c_MT_m_r_dth, c_MT_m_r_bar = c_MT.rips_complex(c_MT.atoms_m_m, c_MT.atoms_m_o)
c_MT_s_r_dth, c_MT_s_r_bar = c_MT.rips_complex(c_MT.atoms_m_m, c_MT.atoms_m_s)

c_MT_b_a, c_MT_b_a_all = c_MT.alpha_shape(c_MT.atoms_b_m, c_MT.atoms_b_o)
c_MT_m_a, c_MT_m_a_all = c_MT.alpha_shape(c_MT.atoms_m_m, c_MT.atoms_m_o)
c_MT_s_a, c_MT_s_a_all = c_MT.alpha_shape(c_MT.atoms_m_m, c_MT.atoms_m_s)

c_MT_dist_b   = c_MT.FRI_dists(c_MT.atoms_b_m, c_MT.atoms_b_o)
c_MT_dist_m_o = c_MT.FRI_dists(c_MT.atoms_m_m, c_MT.atoms_m_o)
c_MT_dist_m_s = c_MT.FRI_dists(c_MT.atoms_m_m, c_MT.atoms_m_s)
#----------------------------------------------------------------------------------------
feature_PH0  = construct_features_PH0(c_WT_b_r_dth, c_WT_b_r_bar, c_MT_b_r_dth, c_MT_b_r_bar,
                                      c_WT_m_r_dth, c_WT_m_r_bar, c_MT_m_r_dth, c_MT_m_r_bar,
                                      c_WT_s_r_dth, c_WT_s_r_bar, c_MT_s_r_dth, c_MT_s_r_bar)
feature_PH12 = construct_features_PH12(c_WT_b_a, c_WT_b_a_all, c_MT_b_a, c_MT_b_a_all, 
                                       c_WT_m_a, c_WT_m_a_all, c_MT_m_a, c_MT_m_a_all,
                                       c_WT_s_a, c_WT_s_a_all, c_MT_s_a, c_MT_s_a_all)
feature_FRI  = construct_features_FRI(c_WT,          c_MT,
                                      c_WT_dist_b,   c_MT_dist_b,
                                      c_WT_dist_m_o, c_MT_dist_m_o,
                                      c_WT_dist_m_s, c_MT_dist_m_s)
#----------------------------------------------------------------------------------------
feature_PH0_inv  = construct_features_PH0(c_MT_b_r_dth, c_MT_b_r_bar, c_WT_b_r_dth, c_WT_b_r_bar,
                                          c_MT_m_r_dth, c_MT_m_r_bar, c_WT_m_r_dth, c_WT_m_r_bar,
                                          c_MT_s_r_dth, c_MT_s_r_bar, c_WT_s_r_dth, c_WT_s_r_bar)
feature_PH12_inv = construct_features_PH12(c_MT_b_a, c_MT_b_a_all, c_WT_b_a, c_WT_b_a_all, 
                                           c_MT_m_a, c_MT_m_a_all, c_WT_m_a, c_WT_m_a_all,
                                           c_MT_s_a, c_MT_s_a_all, c_WT_s_a, c_WT_s_a_all)
feature_FRI_inv  = construct_features_FRI(c_MT,          c_WT,
                                          c_MT_dist_b,   c_WT_dist_b,
                                          c_MT_dist_m_o, c_WT_dist_m_o,
                                          c_MT_dist_m_s, c_WT_dist_m_s)
#########################################################################################
print('auxiliary feature size: ', feature_aux.shape , feature_aux.shape )
print('FRI feature size:       ', feature_FRI.shape , feature_FRI.shape )
print('PH0 feature size:       ', feature_PH0.shape , feature_PH0.shape )
print('PH12 feature size:      ', feature_PH12.shape, feature_PH12.shape)
feature = np.concatenate((feature_aux, feature_FRI))
feature = np.concatenate((feature, feature_PH0))
feature = np.concatenate((feature, feature_PH12))

feature_inv = np.concatenate((feature_aux_inv, feature_FRI_inv))
feature_inv = np.concatenate((feature_inv, feature_PH0_inv))
feature_inv = np.concatenate((feature_inv, feature_PH12_inv))

OutFile = open(filename+'.npy', 'wb')
np.save(OutFile, feature)
OutFile.close()

OutFile = open(filename_inv+'.npy', 'wb')
np.save(OutFile, feature_inv)
OutFile.close()
