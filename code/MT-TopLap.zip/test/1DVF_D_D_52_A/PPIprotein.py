import os, pickle, operator, sys, gudhi
import numpy as np
import scipy as sp
from Bio.PDB.Polypeptide import three_to_one
from Bio.PDB.PDBParser import PDBParser
from Bio.PDB.DSSP import DSSP
from Bio.Blast.Applications import NcbipsiblastCommandline
from scipy.spatial import cKDTree

FRIDefault = [['Lorentz', 0.5,  5],
              ['Lorentz', 1.0,  5],
              ['Lorentz', 2.0,  5],
              ['Exp',     1.0, 15],
              ['Exp',     2.0, 15]]
ele2index = {'C':0, 'N':1, 'O':2, 'S':3, 'H':4}
ss2index = {'H':1, 'E':2, 'G':3, 'S':4, 'B':5, 'T':6, 'I':7, '-':0}
Hydro = ['A', 'V', 'I', 'L', 'M', 'F', 'Y', 'W']
PolarAll = ['S','T','N','Q','R','H','K','D','E']
PolarUncharged = ['S','T','N','Q']
PolarPosCharged = ['R','H','K']
PolarNegCharged = ['D','E']
SpecialCase = ['C','U','G','P']
AAvolume = {'A': 88.6, 'R':173.4, 'D':111.1, 'N':114.1, 'C':108.5, \
            'E':138.4, 'Q':143.8, 'G': 60.1, 'H':153.2, 'I':166.7, \
            'L':166.7, 'K':168.6, 'M':162.9, 'F':189.9, 'P':112.7, \
            'S': 89.0, 'T':116.1, 'W':227.8, 'Y':193.6, 'V':140.0}
AAhydropathy = {'A': 1.8, 'R':-4.5, 'N':-3.5, 'D':-3.5, 'C': 2.5, \
                'E':-3.5, 'Q':-3.5, 'G':-0.4, 'H':-3.2, 'I': 4.5, \
                'L': 3.8, 'K':-3.9, 'M': 1.9, 'F': 2.8, 'P':-1.6, \
                'S':-0.8, 'T':-0.7, 'W':-0.9, 'Y':-1.3, 'V': 4.2}
AAarea = {'A':115., 'R':225., 'D':150., 'N':160., 'C':135., \
          'E':190., 'Q':180., 'G': 75., 'H':195., 'I':175., \
          'L':170., 'K':200., 'M':185., 'F':210., 'P':145., \
          'S':115., 'T':140., 'W':255., 'Y':230., 'V':155.}
AAweight = {'A': 89.094, 'R':174.203, 'N':132.119, 'D':133.104, 'C':121.154, \
            'E':147.131, 'Q':146.146, 'G': 75.067, 'H':155.156, 'I':131.175, \
            'L':131.175, 'K':146.189, 'M':149.208, 'F':165.192, 'P':115.132, \
            'S':105.093, 'T':119.12 , 'W':204.228, 'Y':181.191, 'V':117.148}
AApharma = {'A':[0,1,3,1,1,1],'R':[0,3,3,2,1,1],'N':[0,2,4,1,1,0],'D':[0,1,5,1,2,0],\
            'C':[0,2,3,1,1,0],'E':[0,1,5,1,2,0],'Q':[0,2,4,1,1,0],'G':[0,1,3,1,1,0],\
            'H':[0,3,5,3,1,0],'I':[0,1,3,1,1,2],'L':[0,1,3,1,1,1],'K':[0,2,4,2,1,2],\
            'M':[0,1,3,1,1,2],'F':[1,1,3,1,1,1],'P':[0,1,3,1,1,1],'S':[0,2,4,1,1,0],\
            'T':[0,2,4,1,1,1],'W':[2,2,3,1,1,2],'Y':[1,2,4,1,1,1],'V':[0,1,3,1,1,1]}
Groups = [Hydro, PolarAll, PolarUncharged, PolarPosCharged, PolarNegCharged, SpecialCase]

def atmtyp_to_ele( st ):
    if len(st.strip()) == 1:
        return st.strip()
    elif st[0] == 'H':
        return 'H'
    elif st == "CA":
        return "CA"
    elif st == "CL":
        return "CL"
    elif st == "BR":
        return "BR"
    else:
        print(st, 'Not in dictionary')
        return

def FRIKernel(st, tau, pwr, temp):
    if st == 'Lorentz':
        return 1./(1. + np.power(temp/tau, pwr))
    elif st == 'Exp':
        return np.exp(-np.power(temp/tau, pwr))
    else:
        print('The input FRI kernel type is not defined.')
        sys.exit()

def AAcharge(AA):
    if AA in ['D','E']:
        return -1.
    elif AA in ['R','H','K']:
        return 1.
    else:
        return 0.

class atom:
    def __init__(self, AType, AVType, Charge, Chain, ResName, ResID, Radii):
        self.pos         = None
        self.atype       = AType
        self.verboseType = AVType
        self.Charge      = Charge
        self.ResName     = ResName
        self.ResID       = ResID
        self.R           = Radii
        self.Chain       = Chain
        self.Area        = 0.
        self.SolvEng     = 0.
    def position(self, pos):
        self.pos = pos

class protein:
    def __init__(self, PDBid, Body, Chain, ResName, ResID, pH, ResIDSeq, Sequence, typeFlag):
        self.PDBid    = PDBid
        self.Body     = Body
        self.Chain    = Chain
        self.ResName  = ResName
        self.ResID    = ResID
        self.pH       = pH
        self.ResIDSeq = ResIDSeq
        self.Sequence = Sequence
        self.typeFlag = typeFlag
        self.SeqLength  = len(Sequence)

        self.filename = '_'.join([self.PDBid, self.Body, self.typeFlag])
        self.filename_single = '_'.join([self.PDBid, self.Chain, self.typeFlag])

        # Atom position from PQR file
        self.AtomPos = []
        self.Atoms   = []
        self.Charge  = []

        # load by runMIBPB()
        self.Area         = []
        self.SolvEng      = []
        self.TotalArea    = 0.
        self.TotalVolume  = 0.
        self.TotalSolvEng = 0.

    def loadPQRFile(self):
        print('load PQR file >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
        PQRFile = open(self.filename+'.pqr')
        for line in PQRFile:
            if line[0:4] == 'ATOM':
                resname = line[17:20]
                if resname=='HSE': 
                    resname='HIS'
                self.AtomPos.append([float(line[26:38]), float(line[38:46]), float(line[46:54])])
                Atom = atom(atmtyp_to_ele(line[12:14]), line[11:17], float(line[54:62]),
                            line[21], three_to_one(resname), int(line[22:26]), float(line[62:69]))
                self.Atoms.append(Atom)
                self.Charge.append(float(line[54:62]))
        PQRFile.close()
        self.AtomNum = len(self.Atoms)
        self.AtomPos = np.array(self.AtomPos)
        for idx, iPos in enumerate(self.AtomPos):
            self.Atoms[idx].position(iPos)

    def get_pka_info(self):
        print('get pKa information >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
        pKaFile = open(self.filename+'.propka')
        self.pKaSite = 0.0
        self.pKa = []
        self.pKaName = []
        self.pKaCt = 0.
        self.PKaNt = 0.
        for line in pKaFile:
            if len(line)<24:
                continue
            if line[23]=='%':
                if line[0:2]=='C-':
                    self.pKaCt = float(line[11:16])
                if line[0:2]=='N+':
                    self.pKaNt = float(line[11:16])
                resid = int(line[3:7])
                if resid!=self.ResID:
                    self.pKa.append(float(line[11:16]))
                    self.pKaName.append(line[0:3])
                else:
                    self.pKaSite = float(line[11:16])

    def construct_index_list(self, CutNear=10.):
        """ Lists that contains atom index
            first index: 0 mutsite, 1 other near, 2 all
            seconde index: 0 C, 1 N, 2 O, 3 S, 4 H, 5 heavy, 6 all
        """
        print('constructing index list >>>>>>>>>>>>>>>>>>>>>>>>>>>')
        heavy = ['C', 'N', 'O', 'S']
        self.IndexList = [[[] for i in range(7)] for i in range(3)]

        # get the mutation residue index on atoms
        self.IndexMutSite = []
        checkFlag = False
        for idx, iAtom in enumerate(self.Atoms):
            if iAtom.ResID==self.ResID and iAtom.Chain==self.Chain and iAtom.ResName==self.ResName:
                self.IndexMutSite.append(idx)
                checkFlag = True
        if not checkFlag:
            print(iAtom.ResID, iAtom.Chain, iAtom.ResName)
            print(self.ResID,  self.Chain,  self.ResName)
            #os.system('rm '+self.filename+'*')
            sys.exit('Wrong residue ID and name in construct_index_list() '+self.typeFlag)

        NearRes = []
        IndexNear = []
        for idx, iAtom in enumerate(self.Atoms):
            dis = 100000.0
            for j in self.IndexMutSite:
                tmpdis = np.linalg.norm(iAtom.pos-self.Atoms[j].pos)
                if tmpdis < dis:
                    dis = tmpdis
            if dis<CutNear and iAtom.Chain+str(iAtom.ResID) not in NearRes \
               and iAtom.ResID!=self.ResID:
                NearRes.append(iAtom.Chain+str(iAtom.ResID))
        for idx, iAtom in enumerate(self.Atoms):
            if iAtom.Chain+str(iAtom.ResID) in NearRes:
                IndexNear.append(idx)
        for idx in self.IndexMutSite:
            self.IndexList[0][ele2index[self.Atoms[idx].atype]].append(idx)
            if self.Atoms[idx].atype in heavy:
                self.IndexList[0][5].append(idx)
            self.IndexList[0][6].append(idx)
        for idx in IndexNear:
            self.IndexList[1][ele2index[self.Atoms[idx].atype]].append(idx)
            if self.Atoms[idx].atype in heavy:
                self.IndexList[1][5].append(idx)
            self.IndexList[1][6].append(idx)
        for idx, iAtom in enumerate(self.Atoms):
            self.IndexList[2][ele2index[self.Atoms[idx].atype]].append(idx)
            if iAtom.atype in heavy:
                self.IndexList[2][5].append(idx)
            self.IndexList[2][6].append(idx)
        for i in range(3):
            for j in range(7):
                self.IndexList[i][j]=np.array(self.IndexList[i][j], int)

    def setup_pairwise_interaction(self, sCut=10., lCut=40, FRI=FRIDefault):
        print('setup pairwise interaction >>>>>>>>>>>>>>>>>>>>>>>>')
        self.FRI = FRI
        self.CLB = np.zeros([self.AtomNum, 5], float)
        self.VDW = np.zeros([self.AtomNum, 5], float)
        self.RIG = np.zeros([self.AtomNum, len(self.FRI), 5], float)
        t = cKDTree(self.AtomPos)
        NbShort = cKDTree.query_pairs(t, sCut)
        NbLong  = cKDTree.query_pairs(t, lCut)
        # Short cutoff for VDW
        for (i, j) in NbShort:
            ei    = self.Atoms[i].atype.replace(' ', '')
            ej    = self.Atoms[j].atype.replace(' ', '')
            dis   = np.linalg.norm(self.AtomPos[i]-self.AtomPos[j])
            ratio = (self.Atoms[i].R+self.Atoms[j].R)*(self.Atoms[i].R+self.Atoms[j].R)/dis
            vdw   = np.power(ratio, 12) - 2.*np.power(ratio, 6)
            self.VDW[i, ele2index[ej]] += vdw
            self.VDW[j, ele2index[ei]] += vdw
        # Long cutoff for CLB and RIG
        for (i, j) in NbLong:
            ei  = self.Atoms[i].atype.replace(' ', '')
            ej  = self.Atoms[j].atype.replace(' ', '')
            dis = np.linalg.norm(self.AtomPos[i]-self.AtomPos[j])

            clb = self.Atoms[i].Charge*self.Atoms[j].Charge/dis
            self.CLB[i, ele2index[ej]] += clb
            self.CLB[j, ele2index[ei]] += clb

            Rsum = self.Atoms[i].R+self.Atoms[j].R
            if Rsum > 1e-8:
                rig = np.zeros([len(FRI)], float)
                Arg0=[]; Arg1=[]; Arg2=[]; Arg3=[]
                temp = dis/Rsum
                for tp in FRI:
                    Arg0.append(tp[0])
                    Arg1.append(tp[1])
                    Arg2.append(tp[2])
                    Arg3.append(temp)
                rig = list(map(FRIKernel, Arg0, Arg1, Arg2, Arg3))
                rig = np.array(rig, float)
                self.RIG[i, :, ele2index[ej]] += rig[:]
                self.RIG[j, :, ele2index[ei]] += rig[:]

    def construct_feature(self):
        print('construct features >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
        self.Feature = []
        IndexArray = [np.array([0], int),
                      np.array([1], int),
                      np.array([2], int),
                      np.array([3], int),
                      np.array([4], int),
                      np.array([0,1,2,3], int),
                      np.array([0,1,2,3,4], int)]
        # SolvEng
        SolvEng = np.array(self.SolvEng, float)
        for i in range(3):
            for j in range(7):
                self.Feature.append(np.sum(SolvEng[self.IndexList[i][j]]))
        # Area
        Area = np.array(self.Area, float)
        for i in range(3):
            for j in range(7):
                self.Feature.append(np.sum(Area[self.IndexList[i][j]]))
        # Charge
        Charge = np.array(self.Charge, float)
        for i in range(3):
            for j in range(7):
                self.Feature.append(np.sum(Charge[self.IndexList[i][j]]))
                self.Feature.append(np.sum(np.abs(Charge[self.IndexList[i][j]])))
        # RIG
        for f in range(len(self.FRI)):
            for i in range(3):
                for j in [0, 1, 2, 3, 5]:
                    self.Feature.append(np.sum(self.RIG[self.IndexList[i][j],:,:]
                                                       [:,np.array([f],int),:]
                                                       [:,:,IndexArray[5]]))
        # VDW
        for i in range(3):
            for j in [0,1,2,3,5]:
                self.Feature.append(np.sum(self.VDW[self.IndexList[i][j],:]
                                                   [:,IndexArray[5]]))
        # CLB
        for i in range(3):
            for j in [0,1,2,3,5]:
                self.Feature.append(np.sum(self.CLB[self.IndexList[i][j]]
                                                   [:,IndexArray[6]]))
                self.Feature.append(np.sum(np.abs(self.CLB[self.IndexList[i][j]]
                                                          [:,IndexArray[6]])))
        # Global
        self.Feature.append(self.TotalSolvEng)
        self.Feature.append(self.TotalArea)
        self.Feature.append(self.TotalVolume)
        # Other
        AA = self.ResName
        for Group in Groups:
            if AA in Group:
                self.Feature.append(1.0)
            else:
                self.Feature.append(0.0)
        self.Feature.append(AAvolume[AA])
        self.Feature.append(AAhydropathy[AA])
        self.Feature.append(AAarea[AA])
        self.Feature.append(AAweight[AA])
        self.Feature.append(AAcharge(AA))
        self.Feature.extend(AApharma[AA])

        return self.Feature

    def construct_environment_feature(self):
        print('construct environment feature >>>>>>>>>>>>>>>>>>>>>')
        self.FeatureEnv = []
        NearSeq = []
        CurResID = -1000
        for i in self.IndexList[1][6]:
            ResID = self.Atoms[i].ResID
            if self.Atoms[i].ResID!=CurResID:
                CurResID = ResID
                NearSeq.append(self.Atoms[i].ResName)
        for Group in Groups:
            cnt = 0.
            for AA in NearSeq:
                if AA in Group:
                    cnt += 1.
            self.FeatureEnv.append(cnt)
            self.FeatureEnv.append(cnt/max(1., float(len(NearSeq))))
        Vol = []; Hyd = []; Area = []; Wgt = []; Chg = []
        phara = [0, 0, 0, 0, 0, 0]
        for AA in NearSeq:
            Vol.append(AAvolume[AA])
            Hyd.append(AAhydropathy[AA])
            Area.append(AAarea[AA])
            Wgt.append(AAweight[AA])
            Chg.append(AAcharge(AA))
            for i in range(6):
                phara[i] += AApharma[AA][i]
        Vol = np.asarray(Vol)
        Hyd = np.asarray(Hyd)
        Area = np.asarray(Area)
        Wgt = np.asarray(Wgt)

        if len(NearSeq) == 0:
            self.FeatureEnv.extend([0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.])
        else:
            self.FeatureEnv.extend([np.sum(Vol), np.sum(Vol)/float(len(NearSeq)), np.var(Vol)])
            self.FeatureEnv.extend([np.sum(Hyd), np.sum(Hyd)/float(len(NearSeq)), np.var(Hyd)])
            self.FeatureEnv.extend([np.sum(Area), np.sum(Area)/float(len(NearSeq)), np.var(Area)])
            self.FeatureEnv.extend([np.sum(Wgt), np.sum(Wgt)/float(len(NearSeq)), np.var(Wgt)])
        self.FeatureEnv.append(sum(Chg))
        self.FeatureEnv.extend(phara)
        return self.FeatureEnv

    def runMIBPB(self, h=0.5):
        print('run MIBPB >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
        if not os.path.exists(self.filename+'.englist') or \
           not os.path.exists(self.filename+'.eng') or \
           not os.path.exists(self.filename+'.arealist') or \
           not os.path.exists(self.filename+'.areavolume'):
            os.system('mibpb5 '+self.filename+' h=%f'%(h))
            os.system('mv partition_area.txt '+self.filename+'.arealist')
            os.system('mv area_volume.dat '+self.filename+'.areavolume')
        os.system('rm -f bounding_box.txt')
        os.system('rm -f grid_info.txt')
        os.system('rm -f intersection_info.txt')
        os.system('rm -f '+self.filename+'.dx')
        # Info from arealist file
        AreaListFile = open(self.filename+'.arealist')
        for idx, line in enumerate(AreaListFile):
            a, b = line.split()
            self.Area.append(float(b))
        AreaListFile.close()
        # Info from englist file
        EngListFile = open(self.filename+'.englist')
        for idx, line in enumerate(EngListFile):
            self.SolvEng.append(float(line))
        EngListFile.close()
        # Info from areavolume file
        AreaVolumeFile = open(self.filename+'.areavolume')
        self.TotalArea = float(AreaVolumeFile.readline())
        self.TotalVolume = float(AreaVolumeFile.readline())
        AreaVolumeFile.close()
        # Info from eng file
        EngFile = open(self.filename+'.eng')
        EngFile.readline()
        self.TotalSolvEng = float(EngFile.readline())
        EngFile.close()

    def runESM(self):
        import torch, esm, re

        # Load ESM-1b model
        model, alphabet = esm.pretrained.esm1b_t33_650M_UR505()
        batch_converter = alphabet.get_batch_converter()
        model.eval() # disables dropout for deterministic results

        # Prepare data fasta file
        Sequence = ''
        if self.SeqLength > 1022:
            if self.ResIDSeq < 1022:
                Sequence = self.Sequence[:1022]
            elif self.ResIDSeq > 1022: # Here need more cares later !!! since no chain's len > 2000
                Sequence = self.Sequence[-1022:]
        else:
            Sequence = self.Sequence
        data = [(self.filename_single, Sequence)]
        batch_labels, batch_strs, batch_tokens = batch_converter(data)

        # Extract per-residue representations (on CPU)
        with torch.no_grad():
            results = model(batch_tokens, repr_layers=[33], return_contacts=True)
        token_representations = results['representations'][33]

        # Generate per-sequence representations via averaging
        # NOTE: token 0 is always a beginning-of-sequence token, so the first residue is token 1.
        sequence_representations = token_representations[0, 1:len(Sequence)+1].mean(0)
        sequence_representations = sequence_representations.numpy()

        return sequence_representations
        
    def runBLAST(self):
        print('run BLAST >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
        cline = NcbipsiblastCommandline(query=self.filename_single+'.fasta',
                                        db='/mnt/research/common-data/Bio/blastdb/nr',
                                        num_iterations=3,
                                        evalue=5000,
                                        out=self.filename_single+'.out',
                                        out_ascii_pssm=self.filename_single+'.pssm')

        if not os.path.exists(self.filename_single+'.pssm'):
            print('running '+self.filename_single+'.pssm')
            stdout, stderr = cline()
            print(stdout, stderr)
        else:
            flag = True
            fp = open(self.filename_single+'.pssm')
            for line in fp:
                if line[:10]=='PSI Gapped':
                    flag = False
            fp.close()
            if flag:
                print('running '+self.filename_single+'.pssm')
                stdout, stderr = cline()
                print(stdout, stderr)

    def secondary_structure(self):
        print('generate secondary structure information >>>>>>>>>>')
        self.FeatureSeq = []

        # Structure based DSSP
        parser = PDBParser()
        structure = parser.get_structure(self.PDBid, self.filename+'.pdb')
        model = structure[0]
        dssp = DSSP(model, self.filename+'.pdb', dssp='mkdssp')
        ssindex = ss2index[dssp[(self.Chain, (' ', self.ResID, ' '))][2]]
        self.FeatureSeq.append(ssindex)

        # Sequence based Spider3
        os.system('../../bin/SPIDER2_local/misc/pred_pssm.py '+self.filename_single+'.pssm -f')
        spdfile = open(self.filename_single+'.spd3')
        lines = spdfile.read().splitlines()
        line = lines[self.ResIDSeq+1] # Here, num+1 is because of the first line of spd3 is header
        if line.split()[1]!=self.ResName:
            print(self.filename_single+'.fasta is removed')
            print(self.filename_single+'.pssm is removed')
            #os.system('rm '+self.filename_single+'.fasta')
            #os.system('rm '+self.filename_single+'.pssm')
            sys.exit('Wrong residue when calling pssm for '+self.typeFlag)
        psi=0.; phi=0.; pc=0.; pe=0.; ph=0.
        d0, d1, d2, d3, phi, psi, d4, d5, pc, pe, ph = line.split()
        spdfile.close()
        self.FeatureSeq.extend([float(phi), float(psi), float(pc), float(pe), float(ph)])

        return self.FeatureSeq
 
def construct_features_aux(p_WT, p_MT):
    Feature = []
    # Regular features
    Feature.extend(p_MT.Feature)
    Feature.extend(p_WT.Feature)
    Feature.extend(map(operator.sub, p_MT.Feature, p_WT.Feature))

    # pKa features
    pKaIndex = {'ASP':0, 'GLU':1, 'ARG':2, 'LYS':3, 'HIS':4, 'CYS':5, 'TYR':6}
    pKaGroup = ['ASP',   'GLU',   'ARG',   'LYS',   'HIS',   'CYS',   'TYR']
    mutpKa   = np.array(p_MT.pKa, float)
    wildpKa  = np.array(p_WT.pKa, float)
    wildpKaname = p_WT.pKaName
    defer = mutpKa-wildpKa
    absmax = np.max(np.abs(defer))
    abssum = np.sum(np.abs(defer))
    maxpos = np.max(defer)
    maxneg = np.min(defer)
    netchange = np.sum(defer)
    DetailShiftAbs = np.zeros([7], float)
    DetailShiftNet = np.zeros([7], float)
    for j in range(len(wildpKa)):
        if wildpKaname[j] in pKaGroup:
            DetailShiftAbs[pKaIndex[wildpKaname[j]]] += np.abs(mutpKa[j]-wildpKa[j])
            DetailShiftNet[pKaIndex[wildpKaname[j]]] += mutpKa[j]-wildpKa[j]
    mutC = p_MT.pKaCt; mutN = p_MT.pKaNt
    wildC = p_WT.pKaCt; wildN = p_WT.pKaNt
    mutsitepKa = p_MT.pKaSite; wildsitepKa = p_WT.pKaSite;
    Feature.extend([absmax, abssum, maxpos, maxneg, netchange, 
                    wildsitepKa, mutsitepKa, mutsitepKa-wildsitepKa, 
                    wildC, mutC, mutC-wildC, wildN, mutN, mutN-wildN])
    Feature.extend(DetailShiftNet.tolist())
    Feature.extend(DetailShiftAbs.tolist())

    # Environment features
    Feature.extend(p_WT.FeatureEnv)

    # PSSM features
    AAind = {'A':1, 'R':2, 'N':3, 'D':4, 'C':5, 'Q':6, 'E':7, 'G':8, 'H':9, 'I':10, \
             'L':11,'K':12,'M':13,'F':14,'P':15,'S':16,'T':17,'W':18,'Y':19,'V':20}
    resWT = p_WT.ResName
    resMT = p_MT.ResName
    resNum = p_MT.ResIDSeq
    pssm_score1 = np.zeros([p_WT.SeqLength, 20])
    pssm_score2 = np.zeros([p_WT.SeqLength, 20])
    pssm_score3 = np.zeros([p_WT.SeqLength, 2])

    pssmfile = open(p_WT.filename_single+'.pssm')
    lines = pssmfile.read().splitlines()
    for idx, line in enumerate(lines[3:3+p_WT.SeqLength]):
        tmp_vec = line.split()
        pssm_score1[idx, :] = tmp_vec[2:22]
        pssm_score2[idx, :] = tmp_vec[22:42]
        pssm_score3[idx, :] = tmp_vec[42:]
    pssmfile.close()

    Feature.append(pssm_score1[p_MT.ResIDSeq, AAind[resMT]-1])
    Feature.append(pssm_score1[p_WT.ResIDSeq, AAind[resWT]-1])
    Feature.append(pssm_score1[p_MT.ResIDSeq, AAind[resMT]-1] \
                  -pssm_score1[p_WT.ResIDSeq, AAind[resWT]-1])
    Feature.append(np.sum(pssm_score1[p_WT.ResIDSeq, :]))

    Feature.append(pssm_score2[p_MT.ResIDSeq, AAind[resMT]-1])
    Feature.append(pssm_score2[p_WT.ResIDSeq, AAind[resWT]-1])
    Feature.append(pssm_score2[p_MT.ResIDSeq, AAind[resMT]-1] \
                  -pssm_score2[p_WT.ResIDSeq, AAind[resWT]-1])
    Feature.append(np.sum(pssm_score2[p_WT.ResIDSeq, :]))

    Feature.extend(pssm_score3[p_WT.ResIDSeq].tolist())

    # SS features
    Feature.extend(p_MT.FeatureSeq)
    Feature.extend(p_WT.FeatureSeq)
    Feature.extend(map(operator.sub, p_MT.FeatureSeq, p_WT.FeatureSeq))

    return np.array(Feature)

