import sys, os
import numpy as np
from PPIstructure import get_structure
from PPIprotein import protein
from PPIprotein import construct_features_aux
from PPIcomplex import pro_complex
from PPIcomplex import construct_features_PH0
from PPIcomplex import construct_features_PH12
from PPIcomplex import construct_features_FRI
from PPIcomplex import construct_features_PGS0

# 1DVF AB CD D D 52 A 7.0
#          arguement    example
PDBid    = sys.argv[1] # 1KBH
Antibody = sys.argv[2] # A
Antigen  = sys.argv[3] # B
Chain    = sys.argv[4] # A
resWT    = sys.argv[5] # L
resID    = sys.argv[6] # 37
resMT    = sys.argv[7] # W
pH       = sys.argv[8] # 7.0

s = get_structure(PDBid, Antibody, Antigen, Chain, resWT, resID, resMT, pH)
filename = PDBid+'_'+Chain+'_'+resWT+'_'+resID+'_'+resMT
filename_inv = PDBid+'_'+Chain+'_'+resMT+'_'+resID+'_'+resWT
#########################################################################################
c_WT = pro_complex(PDBid, s.targetChains, Chain, resWT, s.resID)
c_WT.loadBindingPDB(s.fileComplex+'_WT')
c_WT.loadMutantPDB(s.fileComplex+'_WT')

c_WT_PGS_b = c_WT.rips_complex_spectra(c_WT.atoms_b_m, c_WT.atoms_b_o)
c_WT_PGS_m = c_WT.rips_complex_spectra(c_WT.atoms_m_m, c_WT.atoms_m_o)
c_WT_PGS_s = c_WT.rips_complex_spectra(c_WT.atoms_m_m, c_WT.atoms_m_s)
#----------------------------------------------------------------------------------------
c_MT = pro_complex(PDBid, s.targetChains, Chain, resMT, s.resID)
c_MT.loadBindingPDB(s.fileComplex+'_MT')
c_MT.loadMutantPDB(s.fileComplex+'_MT')

c_MT_PGS_b = c_MT.rips_complex_spectra(c_MT.atoms_b_m, c_MT.atoms_b_o)
c_MT_PGS_m = c_MT.rips_complex_spectra(c_MT.atoms_m_m, c_MT.atoms_m_o)
c_MT_PGS_s = c_MT.rips_complex_spectra(c_MT.atoms_m_m, c_MT.atoms_m_s)
#----------------------------------------------------------------------------------------
feature_PGS0  = construct_features_PGS0(c_WT_PGS_b, c_MT_PGS_b, c_WT_PGS_m, c_MT_PGS_m)
feature_PGS0_s = np.concatenate((c_MT_PGS_s, c_WT_PGS_s), axis=0)
feature_PGS0_s = np.concatenate((feature_PGS0_s, c_MT_PGS_s-c_WT_PGS_s), axis=0)
#----------------------------------------------------------------------------------------
feature_PGS0_inv  = construct_features_PGS0(c_MT_PGS_b, c_WT_PGS_b, c_MT_PGS_m, c_WT_PGS_m)
feature_PGS0_s_inv = np.concatenate((c_WT_PGS_s, c_MT_PGS_s), axis=0)
feature_PGS0_s_inv = np.concatenate((feature_PGS0_s, c_WT_PGS_s-c_MT_PGS_s), axis=0)
#########################################################################################
print('PGS0 feature size:       ', feature_PGS0.shape, feature_PGS0_inv.shape )

OutFile = open(filename+'_PGS0.npy', 'wb')
np.save(OutFile, feature_PGS0)
OutFile.close()

OutFile = open(filename_inv+'_PGS0.npy', 'wb')
np.save(OutFile, feature_PGS0_inv)
OutFile.close()

OutFile = open(filename+'_PGS0_s.npy', 'wb')
np.save(OutFile, feature_PGS0_s)
OutFile.close()

OutFile = open(filename_inv+'_PGS0_s.npy', 'wb')
np.save(OutFile, feature_PGS0_s_inv)
OutFile.close()
