import sys, os
import numpy as np
from PPIstructure import get_structure
from PPIcomplex import pro_complex
from PPIcomplex import construct_features_PH0

# 1DVF AB CD D D 52 A 7.0
#          arguement    example
PDBid    = sys.argv[1] # 1KBH
Antibody = sys.argv[2] # A
Antigen  = sys.argv[3] # B
Chain    = sys.argv[4] # A
resWT    = sys.argv[5] # L
resID    = sys.argv[6] # 37
resMT    = sys.argv[7] # W
pH       = sys.argv[8] # 7.0
for ibir, birth in enumerate([0., 1., 2., 3.]):
    for idea, death in enumerate([11., 12., 13.]):
        # setup PDB_files and other files
        s = get_structure(PDBid, Antibody, Antigen, Chain, resWT, resID, resMT, pH)
        
        # setup and compute complex information
        c_WT = pro_complex(PDBid, s.targetChains, Chain, resWT, s.resID)
        c_WT.loadBindingPDB(s.fileComplex+'_WT')
        c_WT.loadMutantPDB(s.fileComplex+'_WT')
        c_WT_b_r_dth, c_WT_b_r_bar = c_WT.rips_complex(c_WT.atoms_b_m, c_WT.atoms_b_o, birth_cut=birth, death_cut=death)
        c_WT_m_r_dth, c_WT_m_r_bar = c_WT.rips_complex(c_WT.atoms_m_m, c_WT.atoms_m_o, birth_cut=birth, death_cut=death)
        c_WT_s_r_dth, c_WT_s_r_bar = c_WT.rips_complex(c_WT.atoms_m_m, c_WT.atoms_m_s, birth_cut=birth, death_cut=death)
        
        c_MT = pro_complex(PDBid, s.targetChains, Chain, resMT, s.resID)
        c_MT.loadBindingPDB(s.fileComplex+'_MT')
        c_MT.loadMutantPDB(s.fileComplex+'_MT')
        c_MT_b_r_dth, c_MT_b_r_bar = c_MT.rips_complex(c_MT.atoms_b_m, c_MT.atoms_b_o, birth_cut=birth, death_cut=death)
        c_MT_m_r_dth, c_MT_m_r_bar = c_MT.rips_complex(c_MT.atoms_m_m, c_MT.atoms_m_o, birth_cut=birth, death_cut=death)
        c_MT_s_r_dth, c_MT_s_r_bar = c_MT.rips_complex(c_MT.atoms_m_m, c_MT.atoms_m_s, birth_cut=birth, death_cut=death)
        
        feature_PH0 = construct_features_PH0(c_WT_b_r_dth, c_WT_b_r_bar, c_MT_b_r_dth, c_MT_b_r_bar,
                                             c_WT_m_r_dth, c_WT_m_r_bar, c_MT_m_r_dth, c_MT_m_r_bar,
                                             c_WT_s_r_dth, c_WT_s_r_bar, c_MT_s_r_dth, c_MT_s_r_bar)
        feature_PH0_inv = construct_features_PH0(c_MT_b_r_dth, c_MT_b_r_bar, c_WT_b_r_dth, c_WT_b_r_bar,
                                                 c_MT_m_r_dth, c_MT_m_r_bar, c_WT_m_r_dth, c_WT_m_r_bar,
                                                 c_MT_s_r_dth, c_MT_s_r_bar, c_WT_s_r_dth, c_WT_s_r_bar)

        filename = PDBid+'_'+Chain+'_'+resWT+'_'+resID+'_'+resMT
        OutFile = open(filename+'_ph0_'+str(ibir)+'_'+str(idea)+'.npy', 'wb')
        np.save(OutFile, feature_PH0)
        OutFile.close()
        
        filename_inv = PDBid+'_'+Chain+'_'+resMT+'_'+resID+'_'+resWT
        OutFile = open(filename_inv+'_ph0_'+str(ibir)+'_'+str(idea)+'.npy', 'wb')
        np.save(OutFile, feature_PH0_inv)
        OutFile.close()
